%% Runge-Kutta Method
f = @(x, y) y^2 + sin(3*x);
x0 = 0;
y0 = 1;
h = 0.2;    
x_end = 2.4; 
N = floor((x_end - x0) / h);
x = zeros(1, N+1);
y = zeros(1, N+1);
x(1) = x0;
y(1) = y0;
for n = 1:N
    k1 = f(x(n), y(n));
    k2 = f(x(n) + h/2, y(n) + (h/2)*k1);
    k3 = f(x(n) + h/2, y(n) + (h/2)*k2);
    k4 = f(x(n) + h, y(n) + h*k3);
    y(n+1) = y(n) + (h/6)*(k1 + 2*k2 + 2*k3 + k4);
    x(n+1) = x(n) + h;
end
plot(x, y, 'b-o',);
xlabel('x');
ylabel('y(x)');
title(' Runge-Kutta Solution');
grid on;