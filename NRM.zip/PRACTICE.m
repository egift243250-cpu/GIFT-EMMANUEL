% Newton Raphson Method
% define function and its derivative
f=@(x) x.^3-x-2; % function
df=@(x) 3*x^2-1; % derivative

% initial guess
x0 = 1; %starting guess
tolerance = 1e-6; %stopping criterion for accuracy
maxiteration = 100; %maximum number of iterations

%initialize the variable
x = x0;
iter = 0;

%newton raphson iteration loop
while iter <maxiteration
%compute the next approximation
x_new=x-f(x)/df(x);

% check the solution within the tolerance
if abs(x_new-x)<tolerance
    fprintf('root found at x=%.6f after %d iterations.\n',x_new, iter+1)
    break
end
% update the current value and increment iteration counter
x = x_new;
iter = iter + 1;
end

%if the method did not converge within the maximum iteration
if iter == maxiteration
    fprintf('method did not converge after %d iteration.\n',maxiteration);
end

%plotting the function f(x)

x_values = linspace(-2,2,100);
y_values = arrayfun(f,x_values);%evaluate f(x) at points in x_values
figure;

plot(x_values,y_values,'r-','LineWidth',2);%plot f(x)
hold on
%plot the root 
plot(x_new,f(x_new),'bo-','markersize',10,'MarkerFaceColor','b');
xlabel('X');
ylabel('f(x)');
title('NRM GRAPH');
legend('f(x)','Root')
grid on
