function NumericalSolverApp
% NUMERICALSOLVERAPP Creates a graphical user interface for the numerical solvers.
% This script assumes that 'NumericalSolver.m', 'DifferentialProblem.m' and 'IntergrationProblem.m' are in the MATLAB path.

    %1. Setup the Main Figure and Layout
    f = uifigure('Name', 'NUMERICAL SOLVER APPLICATION', 'Position', [100 100 750 600]);
    % Panel for Inputs
    pInput = uipanel(f, 'Title', 'Input Parameters', 'Position', [20 350 300 230]);
    
    % Panel for Controls
    pControl = uipanel(f, 'Title', 'Solver Control', 'Position', [20 200 300 130]);

    % Axes for Plotting
    ax = uiaxes(f, 'Position', [340 50 400 530]);
    title(ax, 'Solution Plot');
    xlabel(ax, 'Time (t) / Iterations');
    ylabel(ax, 'Population (P) / Function Value (f(r))');

    % Text Area for Results
    taResults = uitextarea(f, 'Position', [20 20 300 170], 'Editable', 'off', 'Value', {'Solved Results Will Appear Here.'});
    
    % 2. Input Components (within pInput)
    
    % Label for Method Selection
    uilabel(pInput, 'Text', 'Select Method:', 'Position', [10 185 100 22]);
    
    % Dropdown Menu for Method Selection
    ddMethod = uidropdown(pInput, ...
        'Items', {'NRM', 'Secant', 'Euler', 'RungeKutta'}, ...
        'Value', 'NRM', ...
        'Position', [120 185 150 22], ...
        'ValueChangedFcn', @methodSelectionChanged);

    % Labels and fields for parameters (dynamically change based on method)
    lblParam1 = uilabel(pInput, 'Text', 'Current Value:', 'Position', [10 150 100 22]);
    efParam1 = uieditfield(pInput, 'numeric', 'Value', 10000000, 'Position', [120 150 150 22]);

    lblParam2 = uilabel(pInput, 'Text', 'Future Value:', 'Position', [10 120 100 22]);
    efParam2 = uieditfield(pInput, 'numeric', 'Value', 15000000, 'Position', [120 120 150 22]);

    lblParam3 =uilabel(pInput, 'Text', 'Period (Years):', 'Position', [10 90 100 22]);
    efParam3 = uieditfield(pInput, 'numeric', 'Value', 12, 'Position', [120 90 150 22]);

    lblGuess = uilabel(pInput, 'Text', 'Initial Guess(es) (r/P0):', 'Position', [10 60 150 22]);
    efGuess = uieditfield(pInput, 'text', 'Value', '0.05', 'Position', [170 60 100 22]); % Initial guess for NRM/Secant

   

    % Initial call to set up the fields for the default method (NRM)
    methodSelectionChanged(ddMethod); 

    % 3. Control Components (within pControl)
    
    % Solve Button
    uibutton(pControl, 'Text', 'Solve', ...
        'Position', [50 65 200 40], ...
        'ButtonPushedFcn', @solveButtonPushed);
    
    % Reset Button
    uibutton(pControl, 'Text', 'Clear Plot & Results', ...
        'Position', [130 20 150 40], ...
        'ButtonPushedFcn', @resetButtonPushed);
    % Save Button
    uibutton(pControl, 'Text', 'Save Plot', ...
        'Position', [10 20 110 40], ...
        'ButtonPushedFcn', @savePlotButtonPushed);

    % 4. Callback Functions

    function methodSelectionChanged(src, ~)
        method = src.Value;
        
        switch method
            case {'NRM', 'Secant'}
                % Root Finding Parameters (f(r) = Current value*(1+r)^Period - future value)
                lblParam1.Text = 'Current value:';
                efParam1.Value = 10000000;
                efParam1.Enable = 'on';

                lblParam2.Text = 'Future Value:';
                efParam2.Value = 15000000;
                efParam2.Enable = 'on';

                lblParam3.Text = 'Period (Years):';
                efParam3.Value = 12;
                efParam3.Enable = 'on';

                lblGuess.Text = 'Initial Guess(es):';
                if strcmp(method, 'NRM')
                    efGuess.Value = '0.05'; % Single guess
                else
                    efGuess.Value = '0.05, 0.06'; % Two guesses
                end
                
            case {'Euler', 'RungeKutta4'}
                % ODE Integration Parameters (dP/dt = r*P*(1-P/k))
                lblParam1.Text = 'Growth Rate (r):';
                efParam1.Value = 0.1;
                efParam1.Enable = 'on';

                lblParam2.Text = 'Capacity (K):';
                efParam2.Value = 1000;
                efParam2.Enable = 'on';

                lblParam3.Text = 'Period (Years):';
                efParam3.Value = 12;
                efParam3.Enable = 'off';

                lblGuess.Text = 'Initial Pop (P0):';
                efGuess.Value = '10'; % Single initial population
        end
    end

    function solveButtonPushed(~, ~)
        try
            method = ddMethod.Value;
            
            if ismember(method, {'NRM', 'Secant'})
                % --- Root-Finding Problem (DifferentialProblem) ---
                Current_value = efParam1.Value; % The constant 10000000
                Future_value = efParam2.Value; % The constant 15000000
                Period_Years = efParam3.Value; % The constant 12
                
                % The function: f(r) = A * (1 + r)^12 - B
                rootFunc = @(r) Current_value * (1 + r).^Period_Years - Future_value;
                
                % Parse initial guess(es)
                guessStr = strsplit(efGuess.Value, {',', ' '});
                initialGuesses = str2double(guessStr);
                initialGuesses = initialGuesses(~isnan(initialGuesses)); % Remove invalid entries
                
                if strcmp(method, 'NRM') && length(initialGuesses) ~= 1
                    error('NRM requires one initial guess.');
                elseif strcmp(method, 'Secant') && length(initialGuesses) ~= 2
                    error('Secant requires two initial guesses (e.g., "0.05, 0.06").');
                end

                solver = DifferentialProblem(rootFunc, initialGuesses);
                solver.solve(method);
                
                % Capture display output
                tempOutput = evalc('solver.displayResults()');
                taResults.Value = strsplit(strtrim(tempOutput), '\n');
                
                % Plotting (Root-Finding)
                cla(ax);
                r_vals = linspace(min(initialGuesses)/2, max(initialGuesses)*2, 100);
                if isnan(r_vals(1)) % Fallback for bad initial guess
                    r_vals = linspace(-0.1, 0.2, 100);
                end
                f_vals = rootFunc(r_vals);
                plot(ax, r_vals, f_vals, 'b-', 'LineWidth', 2);
                grid(ax, 'on');
                title(ax, ['Function Plot for ', upper(method)]);
                xlabel(ax, 'Interest Rate (r)');
                ylabel(ax, 'Function Value f(r)');
                
                if ~isnan(solver.result_value)
                    hold(ax, 'on');
                    plot(ax, solver.result_value, 0, 'ro', 'MarkerSize', 10, 'LineWidth', 2);
                    legend(ax, 'f(r)', 'Calculated Root', 'Location', 'best');
                    hold(ax, 'off');
                end
                
            else
                % --- ODE Integration Problem (IntergrationProblem) ---
                r_val = efParam1.Value; % Growth rate 'r'
                k_val = efParam2.Value; % Carrying capacity 'k'
                
                % Initial Population
                P0 = str2double(efGuess.Value);
                if isnan(P0)
                    error('Initial population (P0) must be a single number.');
                end
                
                % Custom IntergrationProblem to use the current r and k values
                customSolver = IntergrationProblem(r_val, k_val, P0);
                customSolver.solve(method);

                % Capture display output
                tempOutput = evalc('customSolver.displayResults()');
                taResults.Value = strsplit(strtrim(tempOutput), '\n');
                
                % Plotting (ODE)
                cla(ax);
                plot(ax, customSolver.time_points, customSolver.solution_y, 'm-', 'LineWidth', 2);
                grid(ax, 'on');
                title(ax, ['Logistic Model Solution (', upper(method), ')']);
                xlabel(ax, 'Time (t)');
                ylabel(ax, 'Population P(t)');
                legend(ax, 'P(t)', 'Location', 'best');
            end

        catch ME
            % Display error message in the results area
            taResults.Value = {['ERROR: ', ME.message]};
            warning(ME.message);
        end
    end

    function resetButtonPushed(~, ~)
        cla(ax);
        title(ax, 'Solution Plot');
        xlabel(ax, 'Time (t) / Iterations');
        ylabel(ax, 'Population (P) / Function Value (f(r))');
        taResults.Value = {'Solver Results Will Appear Here.'};
    end

    function savePlotButtonPushed(~, ~)

        % Define a fixed file name and format
        filename = 'solver_plot_output.png';

        % 1. Check if the axes contains any data to save
        if isempty(ax.Children)
            uialert(f, 'There is no plot data to save.', 'Nothing to Save', 'Icon', 'warning');
            return;
        end

        try
            % 2. Use exportgraphics to save the content of the axes object 'ax'
            % directly to the current working directory.
            exportgraphics(ax, filename);

            % 3. Display a success message
            uialert(f, ...
                ['Plot saved as: ' filename], ...
                'Save Complete', 'Icon', 'success');

        catch ME
            % 4. Handle any errors
            uialert(f, ...
                ['Error saving plot: ' ME.message], ...
                'Save Error', 'Icon', 'error');
        end
    end
end