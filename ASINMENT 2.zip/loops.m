clear
% i = 1
%x1 =0
%xfinal(i) = x1
%tol = 0.05
%x2 =(-2*x1-2)/(x1^2+4*x1+3)
% i =i+1
%xfinal(i) = x2fx
%while abs(x2-x1) >=tol
%        x1 = x2
%        x2 = (-2*x1-2)/(x1^2+4*x1+3)
%        i = i+1
%        xfinal(i) =x2
%end

%plot(xfinal)
%xlabel("iteration")
%ylabel("x solution")

clear
 i = 1;
x1 =0;
xfinal(i) = x1;
tol = 0.0005;
x2 =(-2*x1-2)/(x1^2+4*x1+3);
 i =i+1;
xfinal(i) = x2fx;
while abs(x2-x1) >=tol
        x1 = x2;
       x2 = (-2*x1-2)/(x1^2+4*x1+3);
        i = i+1;
       xfinal(i) =x2;
end

plot(xfinal)
xlabel("iteration")
ylabel("x solution")

