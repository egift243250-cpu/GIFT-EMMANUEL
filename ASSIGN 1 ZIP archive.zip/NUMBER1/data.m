T=readtable('C:\Users\HP\OneDrive\Desktop\DATA\cwurData.csv');
T2012 = T(T.year == 2012; :);
T2013 = T(T.year == 2013; :);
T2014 = T(T.year == 2014; :);
T2015 = T(T.year == 2015; :);